.data
print_fmt:.string "%ld\n" 
.text
.globl main
main:
pushq %rbp
movq %rsp, %rbp
subq $16, %rsp
movq $10, %rax
movq %rax ,-8(%rbp)
while:
movq -8(%rbp) , %rax
cmpq $0, %rax
je endwhile
movq -8(%rbp) , %rax
movq %rax , %rsi
leaq print_fmt(%rip), %rdi
call printf@PLT
movq -8(%rbp) , %rax
pushq %rax
movq $1, %rax
movq %rax, %rcx
popq %rax
subq %rcx ,%rax
movq %rax ,-8(%rbp)
jmp while
endwhile:
movq $0, %rax
leave
ret
.section .note.GNU-stack,"",@progbits
