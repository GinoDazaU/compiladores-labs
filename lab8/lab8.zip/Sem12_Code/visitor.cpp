#include <iostream>
#include "ast.h"
#include "visitor.h"
#include <unordered_map>
using namespace std;
unordered_map<std::string, int> memoria;
///////////////////////////////////////////////////////////////////////////////////
int BinaryExp::accept(Visitor* visitor) {
    return visitor->visit(this);
}

int NumberExp::accept(Visitor* visitor) {
    return visitor->visit(this);
}

int IdExp::accept(Visitor* visitor) {
    return visitor->visit(this);
}

int AssignStm::accept(Visitor* visitor) {
    visitor->visit(this);
    return 0;
}

int PrintStm::accept(Visitor* visitor) {
    visitor->visit(this);
    return 0;
}


int WhileStm::accept(Visitor* visitor) {
    visitor->visit(this);
    return 0;
}

int IfStm::accept(Visitor* visitor) {
    visitor->visit(this);
    return 0;
}
////////////////////////////////////////////////////////////////////
int GencodeVisitor::visit(BinaryExp* exp) {
    exp->left->accept(this);
    cout<< "pushq %rax" << endl;
    exp->right->accept(this);
    switch(exp->op) {
        case PLUS_OP: {
            cout << "movq %rax, %rcx" << endl;
            cout << "popq %rax"<< endl;
            cout << "addq %rcx ,%rax" << endl;
            break;
        }
        case MINUS_OP: {
            cout << "movq %rax, %rcx" << endl;
            cout << "popq %rax"<< endl;
            cout << "subq %rcx ,%rax" << endl;
            break;
        }
        default:
            cout << "Operador desconocido" << endl;
    }
    return 0;
}

int GencodeVisitor::visit(NumberExp* exp) {
    cout << "movq $" << exp->value << ", %rax" << endl; 
    return 0;
}

int GencodeVisitor::visit(IdExp* exp) {
    cout << "movq " << posicion[exp->value] * -8 << "(%rbp) , %rax" << endl;
    return 0;
}

void GencodeVisitor::visit(AssignStm* stm) {
    if(posicion.find(stm->id) == posicion.end()){
        posicion[stm->id] = contador;
        contador++;
    }
    stm->e->accept(this);
    cout << "movq %rax ," << -8 * posicion[stm->id] << "(%rbp)" << endl;
    
}

void GencodeVisitor::visit(PrintStm* stm) {
    stm->e->accept(this);
    cout << "movq %rax , %rsi" << endl;
    cout << "leaq print_fmt(%rip), %rdi" << endl;
    cout << "call printf@PLT" << endl;
}

void GencodeVisitor::gencode(Program* program){
    cout << ".data" << endl;
    cout << "print_fmt:.string \"%ld\\n\" " << endl;
    cout << ".text"<< endl;
    cout << ".globl main"<<endl;
    cout << "main:"<<endl;
    cout << "pushq %rbp" << endl;
    cout << "movq %rsp, %rbp" << endl;
    cout << "subq $16, %rsp" << endl; 
    for(auto i:program->slist){
        i->accept(this);
    }
    cout << "movq $0, %rax" << endl;
    cout << "leave" << endl;
    cout << "ret" << endl;
    cout << ".section .note.GNU-stack,\"\",@progbits" << endl;
};

void GencodeVisitor::visit(IfStm* stm ) { 
    stm-> e -> accept(this);
    cout << "cmpq $0 , %rax" << endl;
    cout << "je else" << endl;
    for(auto i: stm->cuerpo1){
        i->accept(this);
    }
    cout << "jmp endif" << endl;
    cout << "else:" << endl;
    for(auto i: stm->cuerpo2){
        i->accept(this);
    }
    cout << "endif:" << endl;
}

void GencodeVisitor::visit(WhileStm* stm) {
    cout << "while:" << endl;
    stm->e->accept(this);
    cout << "cmpq $0, %rax" << endl;  
    cout << "je endwhile" << endl;
        for(auto i: stm->cuerpo){
        i->accept(this);
    }
    cout << "jmp while" << endl;
    cout << "endwhile:" << endl;
}